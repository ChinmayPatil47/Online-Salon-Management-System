package online.salon.booking.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSalonBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
