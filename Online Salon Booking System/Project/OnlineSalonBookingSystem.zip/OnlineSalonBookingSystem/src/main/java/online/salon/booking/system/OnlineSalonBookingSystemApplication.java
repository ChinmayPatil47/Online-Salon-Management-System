package online.salon.booking.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSalonBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineSalonBookingSystemApplication.class, args);
	}

}
