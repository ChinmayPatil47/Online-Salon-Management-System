package online.salon.booking.system.exception;

public class ApplicationExcepton extends Exception{
	public ApplicationExcepton(String msg) {
     super(msg);
	}

}
