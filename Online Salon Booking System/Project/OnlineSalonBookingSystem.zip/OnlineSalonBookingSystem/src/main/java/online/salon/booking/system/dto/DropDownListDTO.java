package online.salon.booking.system.dto;

public interface DropDownListDTO {
	
	public String getKey();
	
	public String getValue();

}
